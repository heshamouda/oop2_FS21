package utils;

public interface Observer {

	void update(Observable observable, Object obj);

}
